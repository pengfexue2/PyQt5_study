from PyQt5.Qt import *
from PyQt5_Demo.resource.calculator import Ui_Form


class CalculatePane(QWidget, Ui_Form):
    def __init__(self, parent=None, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setupUi(self)


if __name__ == '__main__':
    import sys

    app = QApplication(sys.argv)

    window = CalculatePane()
    window.show()
    sys.exit(app.exec_())
